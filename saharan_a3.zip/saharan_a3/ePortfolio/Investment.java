package ePortfolio;
/*
 * Student Name: Shaan Saharan
 * Student ID: 1128702
 * Course: CIS*2430
 */

/**
 * The public class Investment is used to initialize and calculate the overall funds
**/
public abstract class Investment
{
    //make all variables
    protected String sym;
    protected String name;
    protected int quantity;
    protected double price;
    protected double bookVal;
    protected double gain;

    /**
     * setSym is used to set the symbol
     * @param symEntered used
     * @throws Exception used
     **/
    public void setSym(String symEntered)throws Exception{
        if(symEntered.isEmpty()){
            throw new Exception("Invalid Symbol\n");
        }else{
            this.sym = symEntered;
        }
    }
    /**
     * setName is used to set the name
     * @param nameEntered used
     * @throws Exception used
     **/
    public void setName(String nameEntered)throws Exception{
        if(nameEntered.isEmpty()){
            throw new Exception("Invalid Name\n");
        }else{
            this.name = nameEntered;
        }
    }
    /**
     * setQuantity is used to set the quantity
     * @param quantityEntered used
     **/
    public void setQuantity(Integer quantityEntered)throws NumberFormatException{ 
        if(!(quantityEntered instanceof Integer)){
            throw new NumberFormatException("Invalid quantity\n");
        }else{
            this.quantity = quantityEntered;
        }
    }
    /**
     * setPrice is used to set the price
     * @param priceEntered used
     **/
    public void setPrice(Double priceEntered)throws NumberFormatException{ 
        if(!(priceEntered instanceof Double))
        {
            throw new NumberFormatException("Invalid price\n");
        }else
        {
            this.price = priceEntered;
        }
    }
    /**
     * getSym is used to get the symbols
     * @return sym 
     **/
    public String getSym(){
        return sym;
    }
    /**
     * getName is used to get the name
     * @return name
     **/
    public String getName(){
        return name;
    }
    /**
     * getQuantity is used to get the quantity
     * @return quantity
     **/
    public int getQuantity(){
        return quantity;
    }
    /**
     * getPrice is used to get the price
     * @return price
     **/
    public double getPrice(){
        return price;
    }
    /**
     * getBookVal is used to get the book value
     * @return bookVal
     **/
    public double getBookVal(){
       return bookVal;
    }
    /**
     * getGain is used to get the overall gain
     * @return (this.quantity*this.price) - this.bookVal;
     **/
    public double getGain(){
        return (this.quantity*this.price) - this.bookVal;
    }

    /**
     * Adds more to buy if more is bought by the user
     * @param updatedQuantity used
     * @param updatedPrice used
     * @param updateBookVal used
     **/
    public void additional(int updatedQuantity, double updatedPrice, double updateBookVal){
        //adding the value
        this.quantity = this.quantity + updatedQuantity;
        this.price = updatedPrice;
        this.bookVal += updateBookVal;
        //calculate
        //this.bookVal = this.bookVal + (updatedQuantity * updatedPrice);
    }

    /** this method checks if a given mutualFund is equal to the other mutualFund.
     * @param input used
     * @return true or false
    */
    public Boolean equals(Investment input)
    {
        if ((this.name == input.name) && (this.sym == input.sym) && (this.quantity == input.quantity) && (this.price == input.price) && (this.bookVal == input.bookVal))
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    /**
     * Outputs the desired output
     **/
    public String toString()
    {
        return "\nName:\t" + this.getName() +
        "\nSymbol:\t" + this.getSym() +
        "\nQuantity:\t" + this.getQuantity() +
        "\nPrice:\t" + this.getPrice() +
        "\nBook Value:\t" + this.getBookVal();
    }
}

/**
 * The class extension MutualFund is used to initialize and calculate the overall funds
**/
class MutualFund extends Investment
{
    /**
     * Updates the price when called upon
     * @param updatedPrice used
     **/
    public void update(double updatedPrice)
    {
        //define
        double updatedBookVal = this.quantity * updatedPrice;
        //update the pirce
        this.price = updatedPrice;
        this.bookVal = updatedBookVal + 45;
    }
    /**
     * Sells a portion of owned
     * @param updatedPrice used
     * @param updatedQuantity used
     **/
    public double sellBit(double updatedPrice, int updatedQuantity)
    {
        //define
        double commision = 45;
        double payment  = 0.0;
        double profit = 0.0;
        double bookValTemp = 0.0;
        
        //calcuate the profit
        payment = (updatedQuantity * updatedPrice) - commision;
        profit = payment - this.bookVal * (((double)updatedQuantity) / (double)this.quantity);
        bookValTemp = this.bookVal * (((double)updatedQuantity) / this.quantity);
        this.bookVal = this.bookVal - bookValTemp;
        this.quantity = this.quantity - updatedQuantity;
        return profit;
    }
    /**
     * Sells entired owned
     * @param updatedPrice used
     * @param updatedQuantity used
     **/
    public double sellAll(double updatedPrice, int updatedQuantity)
    {
        //define
        double commision = 45;
        double payment  = 0.0;
        double profit = 0.0;
        
        //calcuate the profit
        payment = (updatedQuantity * updatedPrice) - commision;
        profit = payment - this.bookVal;
        return profit;
    }
    /**
     * setBookVal is used to set the book value
     * @param updatedPrice used
     * @param updatedQuantity used
     **/
    public void setBookVal(double updatedPrice, int updatedQuantity) throws NumberFormatException
    {
        this.bookVal = updatedPrice * updatedQuantity + 45;
    }
}

/**
 * The class extension Stock is used to initialize and calculate the overall funds
**/
class Stock extends Investment
{
    /**
     * Updates the price when called upon
     * @param updatedPrice used
     **/
    public void update(double updatedPrice)
    {
        //define
        double updatedBookVal = this.quantity * updatedPrice;
        //update the pirce
        this.price = updatedPrice;
        this.bookVal = updatedBookVal + 9.99;
    }
    /**
     * Sells a portion of owned
     * @param updatedPrice used
     * @param updatedQuantity used
     **/
    public double sellBit(double updatedPrice, int updatedQuantity)
    {
        //define
        double commision = 9.99;
        double payment  = 0.0;
        double profit = 0.0;
        double bookValTemp = 0.0;
        
        //calcuate the profit
        payment = (updatedQuantity * updatedPrice) - commision;
        profit = payment - this.bookVal * (((double)updatedQuantity) / (double)this.quantity);
        bookValTemp = this.bookVal * (((double)updatedQuantity) / this.quantity);
        this.bookVal = this.bookVal - bookValTemp;
        this.quantity = this.quantity - updatedQuantity;
        return profit;
    }
    /**
     * Sells entired owned
     * @param updatedPrice used
     * @param updatedQuantity used
     **/
    public double sellAll(double updatedPrice, int updatedQuantity)
    {
        //define
        double commision = 9.99;
        double payment  = 0.0;
        double profit = 0.0;
        
        //calcuate the profit
        payment = (updatedQuantity * updatedPrice) - commision;
        profit = payment - this.bookVal;
        return profit;
    }
    /**
     * setBookVal is used to set the book value
     * @param updatedPrice used
     * @param updatedQuantity used
     **/
    public void setBookVal(double updatedPrice, int updatedQuantity) throws NumberFormatException
    {
        this.bookVal = updatedPrice * updatedQuantity + 9.99;
    }
}
