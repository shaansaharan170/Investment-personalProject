package ePortfolio;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/*
 * Student Name: Shaan Saharan
 * Student ID: 1128702
 * Course: CIS*2430
 */

/**
 * Holds all the details to run the GUI using the investment class
 * and will execute the user's input through an interface that will
 * make it much more user friendly to use
**/
public class Portfolio extends JFrame
{

    /**
     * Main contains the details for running the overall code and
     * executes the Investment function based on the user's inputs
     * through a GUI
     * @param args not used
     **/
    public static void main(String[] args)
    {
        Portfolio layOut = new Portfolio();
        layOut.setVisible(true);
    }

    //declare the array lists that will be used for the rest of the program
    ArrayList <Investment> investmentList = new ArrayList <Investment>();
    ArrayList<Double> tG = new ArrayList<>();
    ArrayList<Integer> location = null;
    ArrayList<JTextField> textFields = new ArrayList<>();
    Map<String, ArrayList<Integer>> hash = new HashMap<String, ArrayList<Integer>>();
    //initialize
    private JPanel controlPanel;
    private JPanel panel = new JPanel();
    //set the buttons text
    private JTextField sym;
    private JTextField name;
    private JTextField quantity;
    private JTextField price;
    private JTextField sellSym;
    private JTextField sellQuan;
    private JTextField sellPrice;
    //updates
    private JTextField symNew;
    private JTextField nameNew;
    private JTextField priceNew;
    private JTextField gainNew;
    //hash map search
    private JTextField match;
    private JTextField low;
    private JTextField high;
    //messages
    private JTextArea outputMessage;
    private JTextArea personalGain;
    private JLabel header;
    //buttons
    JButton prevButton;
    JButton nextButton;
    JButton saveButton;
    //list drop down
    private JComboBox<String> chooseType;
    Stock stockList = null;
    MutualFund mutualFundList = null;
    String[] type = {"Stock", "MutualFund"};
    String nameOfInv;
    String[] split;
    Integer sellingShares;
    int index1 = 0;
    int index2 = 0;
    int sizeInv = 0;
    int moveThrough = 0;
    double sellPrice1;
    double currGain;
    double totGain;

    //set boolean expressions
    boolean buyBool = false;
    boolean sellBool = false; 
    boolean searchBool = false;
    boolean foundBool = false;
    boolean trueBool = false;
    boolean clickBool = false;

    boolean exc = false;
    boolean symEmpty = false;
    boolean quanEmpty = false;
    boolean nameEmpty = false;
    boolean priceEmpty = false;
    boolean enable = false;

    boolean sym1 = false;
    boolean name1 = false;
    boolean quan1 = false;
    boolean price1 = false;
    boolean BuyGoThrough = false;

    MenuThings select = new MenuThings();
    /**
     * Allows the menu to have certain functions that will run
     */
    private class MenuThings implements ActionListener
    {
        @Override
        /**
         * This will preform the actions for the MenuThings
         */
        public void actionPerformed(ActionEvent e)
        {
            buyBool = false; //set false
            sellBool = false; //set false
            searchBool = false; //set false
            String chooseMenu = e.getActionCommand();
            Font labelFont = new Font(Font.SERIF, Font.PLAIN, 16);
            Font headerFont = new Font(Font.SERIF, Font.BOLD, 18);
            if(chooseMenu.equals("Buy New investmentList"))
            {
                //set the bools
                symEmpty = false;
                nameEmpty = false;
                quanEmpty = false;
                priceEmpty = false;
                BuyGoThrough = false;
                buyBool = true;

                panel.setVisible(false);
                controlPanel.remove(panel);
                header.setText("");
                panel = new JPanel();
                panel.setLayout(null);
                panel.setBackground(Color.lightGray);
                JLabel header = new JLabel("Buying an Investment"); //set label
                header.setBounds(15, 25, 205, 30);
                header.setFont(headerFont);
                panel.add(header);
                chooseType = new JComboBox<>(type);
                chooseType.addActionListener(rewind);
                chooseType.setBounds(155, 55, 170, 30);
                panel.add(chooseType);
                sym = new JTextField(25);
                sym.setBounds(155, 85, 170, 30);
                panel.add(sym);
                textFields.add(sym);
                name = new JTextField(25);
                name.setBounds(155, 115, 230, 30);
                panel.add(name);
                textFields.add(name);
                quantity = new JTextField(25);
                quantity.setBounds(155, 145, 170, 30);
                panel.add(quantity);
                textFields.add(quantity);
                price = new JTextField(25);
                price.setBounds(155, 175, 160, 30);
                panel.add(price);
                textFields.add(price);
                //set the labels
                JLabel typeL = new JLabel("Type"); //set label
                JLabel symL = new JLabel("Symbol"); //set label
                JLabel nameL = new JLabel("Name"); //set label
                JLabel quanL = new JLabel("Quantity"); //set label
                JLabel priceL = new JLabel("Price"); //set label
                JLabel messageL = new JLabel("Messages"); //set label
                typeL.setBounds(15, 55, 115, 30);
                typeL.setFont(labelFont);
                panel.add(typeL);
                symL.setBounds(15, 85, 115, 30);
                symL.setFont(labelFont);
                panel.add(symL);
                nameL.setBounds(15, 115, 115, 30);
                nameL.setFont(labelFont);
                panel.add(nameL);
                quanL.setBounds(15, 145, 115, 30);
                quanL.setFont(labelFont);
                panel.add(quanL);
                priceL.setBounds(15, 175, 115, 30);
                priceL.setFont(labelFont);
                panel.add(priceL);
                messageL.setBounds(15, 255, 115, 30);
                messageL.setFont(labelFont);
                panel.add(messageL);
                //txt's
                outputMessage = new JTextArea();
                outputMessage.setBounds(15, 285, 565, 245);
                outputMessage.setEditable(false);
                panel.add(outputMessage);
                //scroll pane
                JScrollPane dropText = new JScrollPane(outputMessage);
                dropText.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
                dropText.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
                dropText.setBounds(15, 285, 565, 245);
                panel.add(dropText);
                //buttons
                JButton restartButton = new JButton("Reset"); //set button
                JButton buyButton = new JButton("Buy"); //set button
                restartButton.setBounds(405, 85, 115, 50);
                restartButton.addActionListener(rewind);
                panel.add(restartButton);
                buyButton.setBounds(405, 145, 115, 50);
                buyButton.addActionListener(rewind);
                panel.add(buyButton);
                controlPanel.add(panel);
                add(controlPanel);
            }
            else if(chooseMenu.equals("Sell Existing investmentList"))
            {
                sellBool = true;
                panel.setVisible(false);
                controlPanel.remove(panel);

                header.setText("");
                panel = new JPanel();
                panel.setLayout(null);

                JLabel titleS = new JLabel("Selling an investment"); //set label
                titleS.setBounds(15, 25, 205, 30);
                titleS.setFont(headerFont);
                panel.add(titleS);

                //txt's
                sellSym = new JTextField(25);
                sellSym.setBounds(155, 55, 170, 30);
                panel.add(sellSym);
                sellQuan = new JTextField(25);
                sellQuan.setBounds(155, 115, 170, 30);
                panel.add(sellQuan);
                sellPrice = new JTextField(25);
                sellPrice.setBounds(155, 175, 170, 30);
                panel.add(sellPrice);
                //set the labels
                JLabel symL = new JLabel("Symbol"); //set label
                JLabel quanL = new JLabel("Quantity"); //set label
                JLabel priceL = new JLabel("Price"); //set label
                JLabel messageL = new JLabel("Messages"); //set label
                symL.setBounds(15, 55, 115, 30);
                symL.setFont(labelFont);
                panel.add(symL);
                quanL.setBounds(15, 115, 115, 30);
                quanL.setFont(labelFont);
                panel.add(quanL);
                priceL.setBounds(15, 175, 115, 30);
                priceL.setFont(labelFont);
                panel.add(priceL);
                messageL.setBounds(15, 255, 115, 30);
                messageL.setFont(labelFont);
                panel.add(messageL);
                //txt's
                outputMessage = new JTextArea();
                outputMessage.setBounds(15, 285, 565, 245);
                outputMessage.setEditable(false);
                panel.add(outputMessage);
                //scroll pane
                JScrollPane dropText = new JScrollPane(outputMessage);
                dropText.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
                dropText.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
                dropText.setBounds(15, 285, 565, 245);
                panel.add(dropText);
                //buttons
                JButton resetButton = new JButton("Reset"); //set button
                JButton sellButton = new JButton("Sell"); //set button
                resetButton.setBounds(405, 85, 115, 50);
                resetButton.addActionListener(rewind);
                panel.add(resetButton);
                sellButton.setBounds(405, 145, 115, 50);
                sellButton.addActionListener(rewind);
                panel.add(sellButton);

                controlPanel.add(panel);
                add(controlPanel);
            }
            else if(chooseMenu.equals("Update Prices of Existing investmentList"))
            {
                panel.setVisible(false); //set the panel visible
                controlPanel.remove(panel); //remove the control panel
                header.setText("");
                panel = new JPanel();
                panel.setLayout(null);
                JLabel header = new JLabel("Updating investmentList"); //set label
                header.setBounds(15, 25, 205, 30);
                header.setFont(headerFont);
                panel.add(header);
                //txt's
                symNew = new JTextField(25);
                symNew.setBounds(155, 55, 170, 30);
                symNew.setEditable(false);
                panel.add(symNew);
                nameNew = new JTextField(25);
                nameNew.setBounds(155, 115, 170, 30);
                nameNew.setEditable(false);
                panel.add(nameNew);
                priceNew = new JTextField(25);
                priceNew.setBounds(155, 175, 170, 30);
                panel.add(priceNew);
                //set the labels
                JLabel symL = new JLabel("Symbol"); //set label
                JLabel nameL = new JLabel("Name"); //set label
                JLabel priceL = new JLabel("Price"); //set label
                JLabel messageL = new JLabel("Messages"); //set label
                symL.setBounds(15, 55, 115, 30);
                symL.setFont(labelFont);
                panel.add(symL);
                nameL.setBounds(15, 115, 115, 30);
                nameL.setFont(labelFont);
                panel.add(nameL);
                priceL.setBounds(15, 175, 115, 30);
                priceL.setFont(labelFont);
                panel.add(priceL);
                messageL.setBounds(15, 255, 115, 30);
                messageL.setFont(labelFont);
                panel.add(messageL);
                //txt's
                outputMessage = new JTextArea();
                outputMessage.setBounds(15, 285, 565, 245);
                outputMessage.setEditable(false);
                panel.add(outputMessage);
                //scroll panes
                JScrollPane dropText = new JScrollPane(outputMessage);
                dropText.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
                dropText.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
                dropText.setBounds(15, 285, 565, 245);
                panel.add(dropText);
                //buttons
                prevButton = new JButton("Previous"); //set button
                nextButton = new JButton("Next"); //set button
                saveButton = new JButton("Save"); //set button
                prevButton.setBounds(405, 55, 115, 50);
                prevButton.addActionListener(rewind);
                panel.add(prevButton);
                nextButton.setBounds(405, 115, 115, 50);
                nextButton.addActionListener(rewind);
                panel.add(nextButton);
                saveButton.setBounds(405, 175, 115, 50);
                saveButton.addActionListener(rewind);
                panel.add(saveButton);
                sizeInv = investmentList.size();

                if (sizeInv == 0 || sizeInv == 1)
                {
                    prevButton.setEnabled(false);
                    nextButton.setEnabled(false);
                }
                if(sizeInv > 0)
                {
                    symNew.setText(investmentList.get(0).getSym());
                    nameNew.setText(investmentList.get(0).getName());
                }
                controlPanel.add(panel);
                add(controlPanel);
            }
            else if(chooseMenu.equals("Get The Gain of Your Portfolio"))
            {
                double currGain = 0.0; //set current
                double getGain = 0.0; //set the get
                panel.setVisible(false);
                controlPanel.remove(panel);
                header.setText("");
                panel = new JPanel();
                panel.setLayout(null);
                JLabel title1 = new JLabel("Getting Total Gain"); //set label
                JLabel totG = new JLabel("Total Gain"); //set label
                JLabel personal = new JLabel("Individual Gains"); //set label
                title1.setBounds(15, 20, 205, 30);
                title1.setFont(headerFont);
                panel.add(title1);
                totG.setBounds(15, 55, 205, 30);
                totG.setFont(labelFont);
                panel.add(totG);
                personal.setBounds(15, 85, 205, 30);
                personal.setFont(labelFont);
                panel.add(personal);
                gainNew = new JTextField(25);
                gainNew.setEditable(false);
                gainNew.setBounds(100, 55, 205, 30);
                panel.add(gainNew);
                personalGain = new JTextArea();
                personalGain.setBounds(15, 115, 555, 430);
                personalGain.setEditable(false);
                panel.add(personalGain);
                JScrollPane dropText = new JScrollPane(personalGain);
                dropText.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
                dropText.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
                dropText.setBounds(15, 115, 555, 430);
                panel.add(dropText);
                sizeInv = investmentList.size();
                for(int index1 = 0; index1 < sizeInv; index1++)
                {
                    currGain = investmentList.get(index1).getGain();
                    tG.add(investmentList.get(index1).getGain());
                    personalGain.append(investmentList.get(index1).getName() + ":\n");
                    personalGain.append("$"+String.valueOf(String.format("%.2f", currGain) + "\n"));
                }
                getGain = getGain + currGain;
                gainNew.setText(String.valueOf(String.format("%.2f", getGain)));

                controlPanel.add(panel);
                add(controlPanel);

            }
            else if(chooseMenu.equals("Search For An Investment"))
            {
                searchBool = true;
                panel.setVisible(false);
                controlPanel.remove(panel);
                header.setText("");
                panel = new JPanel();
                panel.setLayout(null);
                panel.setBackground(Color.lightGray);
                JLabel header = new JLabel("Search investmentList"); //set label
                header.setBounds(15, 25, 205, 30);
                header.setFont(headerFont);
                panel.add(header);
                sym = new JTextField(25);
                sym.addActionListener(rewind);
                sym.setBounds(155, 55, 170, 30);
                panel.add(sym);
                //txt's
                match = new JTextField(25);
                match.setBounds(155, 85, 230, 30);
                panel.add(match);
                low = new JTextField(25);
                low.setBounds(155, 115, 170, 30);
                panel.add(low);
                high = new JTextField(25);
                high.setBounds(155, 145, 170, 30);
                panel.add(high);
                //set the labels
                JLabel symL = new JLabel("Symbol"); //set label
                JLabel nameL = new JLabel("Name Keywords"); //set label
                JLabel lowL = new JLabel("Low"); //set label
                JLabel highL = new JLabel("High"); //set label
                JLabel finalL = new JLabel("Search results"); //set label
                symL.setBounds(15, 55, 115, 30);
                symL.setFont(labelFont);
                panel.add(symL);
                nameL.setBounds(15, 85, 115, 30);
                nameL.setFont(labelFont);
                panel.add(nameL);
                lowL.setBounds(15, 115, 115, 30);
                lowL.setFont(labelFont);
                panel.add(lowL);
                highL.setBounds(15, 145, 115, 30);
                highL.setFont(labelFont);
                panel.add(highL);
                finalL.setBounds(15, 195, 115, 30);
                finalL.setFont(labelFont);
                panel.add(finalL);
                //txt's
                outputMessage = new JTextArea();
                outputMessage.setBounds(15, 225, 565, 245);
                outputMessage.setEditable(false);
                panel.add(outputMessage);
                //scroll panes
                JScrollPane dropText = new JScrollPane(outputMessage);
                dropText.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
                dropText.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
                dropText.setBounds(15, 225, 565, 245);
                panel.add(dropText);
                //buttons
                JButton resetButton = new JButton("Reset"); //set button
                JButton searchButton = new JButton("Search"); //set button
                resetButton.setBounds(405, 55, 115, 50);
                resetButton.addActionListener(rewind);
                panel.add(resetButton);
                searchButton.setBounds(405, 115, 115, 50);
                searchButton.addActionListener(rewind);
                panel.add(searchButton);
                controlPanel.add(panel);
                add(controlPanel);
            }
            else if(chooseMenu.equals("Quit"))
            {
                System.exit(0);
            }else
            {
                System.out.println("unsolved error occured");
            }
        }
    }
    ButtonThings rewind = new ButtonThings();
    /**
     * Allows the menu to have certain functions that will run after the Button preforms
     */
    private class ButtonThings implements ActionListener
    {
         @Override
        /**
         * This will preform the actions for the ButtonThings
         */
        public void actionPerformed(ActionEvent e)
        {
            String button = e.getActionCommand();
            //reset all the buttons
            if(button.equals("Reset"))
            {
                if(buyBool) //reset buy
                { 
                    sym.setText("");
                    name.setText("");
                    quantity.setText("");
                    price.setText("");
                }
                else if(sellBool) //reset sell
                {
                    sellSym.setText("");
                    sellQuan.setText("");
                    sellPrice.setText("");
                }
                else if(searchBool) //reset search
                {
                    sym.setText("");
                    name.setText("");
                    match.setText("");
                    low.setText("");
                    high.setText("");
                }
            }
            else if(button.equals("Buy"))
            {
                //declare
                exc = false;
                outputMessage.setText("");
                String investmentChoose = ""; //initialze
                String symIn = ""; //initialze
                String quanIn = ""; //initialze
                String priceIn = ""; //initialze
                Double tempPrice = 0.0; //initialze
                Integer tempQuan = 0; //initialze
                investmentChoose = (String)chooseType.getSelectedItem(); //let the user choose
                if(sym.getText().isEmpty() || sym.getText().isBlank()) //check
                {
                    outputMessage.append("ERROR: invalid symbol\n");
                    exc = true;
                }
                if(name.getText().isEmpty() || name.getText().isBlank()) //check
                {
                    outputMessage.append("ERROR: invalid name\n");
                    exc = true;
                }
                if(quantity.getText().isEmpty() || quantity.getText().isBlank()) //check
                {
                    outputMessage.append("ERROR: invalid quantity\n");
                    exc = true;
                }
                if(price.getText().isEmpty() || price.getText().isBlank()) //check
                {
                    outputMessage.append("ERROR: invalid price\n");
                    exc = true;
                }
                else
                {
                    double bookVal = 0.0; //declare
                    symIn = sym.getText(); //get the texts
                    nameOfInv = name.getText(); //get the texts
                    quanIn = quantity.getText(); //get the texts
                    priceIn = price.getText(); //get the texts
                    if(symIn.contains(" "))
                    {
                        symIn = symIn.trim(); //trim the output
                    }
                    if(nameOfInv.contains(" "))
                    {
                        nameOfInv = nameOfInv.trim(); //trim the output
                    }
                    if(quanIn.contains(" "))
                    {
                        quanIn = quanIn.trim(); //trim the output
                    }
                    if(priceIn.contains(" "))
                    {
                        priceIn = priceIn.trim(); //trim the output
                    }
                    try
                    {
                        tempPrice = Double.parseDouble(priceIn); //set to double
                        tempQuan = Integer.parseInt(quanIn); //set to int
                    }
                    catch(NumberFormatException nfe)
                    {
                        outputMessage.append("ERROR: invalid price & quantity\n");
                        exc = true; //make true
                    }
                    if(tempPrice < 0.0){
                        outputMessage.append("ERROR: invalid price\n");
                        exc = true; //make true
                    }
                    if(tempQuan < 0){
                        outputMessage.append("ERROR: invalid quantity\n");
                        exc = true; //make true
                    }
                    if(investmentChoose.equals("Stock"))
                    {
                        foundBool = false; //make false
                        sizeInv = investmentList.size();
                        for(index1 = 0; index1 < sizeInv; index1++) //loop through the list
                        {
                            if(symIn.equalsIgnoreCase(investmentList.get(index1).getSym()))
                            {
                                foundBool = true; //make true
                                break;
                            }
                        }
                        if(foundBool)
                        {
                            if(investmentList.get(index1) instanceof MutualFund)
                            {
                                outputMessage.append("Symbol already in MutualFunds"); //let user know
                                exc = true;
                            }
                            else
                            {
                                try
                                {
                                    bookVal = (tempPrice * tempQuan) + 9.99;
                                    investmentList.get(index1).additional(tempQuan, tempPrice, bookVal);
                                }
                                catch(NumberFormatException nfe)
                                {
                                    outputMessage.append("ERROR: invalid price & quantity\n");
                                    exc = true;
                                }
                            }
                        }
                        else
                        {
                            stockList = new Stock();
                            try
                            {
                                stockList.setSym(symIn); //set
                            }
                            catch(Exception r)
                            {
                                outputMessage.append(r.getMessage()); //output message
                                exc = true;
                            }
                            try
                            {
                                stockList.setName(nameOfInv); //set
                            }
                            catch(Exception r)
                            {
                                outputMessage.append(r.getMessage()); //output message
                                exc = true;
                            }
                            try
                            {
                                stockList.setQuantity(tempQuan); //set
                            }
                            catch(NumberFormatException r)
                            {
                                outputMessage.append(r.getMessage()); //output message
                                exc = true;
                            }
                            try
                            {
                                stockList.setPrice(tempPrice); //set
                            }
                            catch(NumberFormatException r){
                                outputMessage.append(r.getMessage()); //output message
                                exc = true;
                            }
                            try
                            {
                                stockList.setBookVal(tempPrice, tempQuan); //set
                            }
                            catch(NumberFormatException r){
                                outputMessage.append("ERROR: cannot create bookVal\n");
                            }
                            if(!exc)
                            {
                                investmentList.add(stockList); //move into list
                            }
                        }
                    }
                    else
                    {
                        foundBool = false; //make false
                        sizeInv = investmentList.size();
                        for(index1 = 0; index1 < sizeInv; index1++) //loop through the list
                        {
                            if(symIn.equalsIgnoreCase(investmentList.get(index1).getSym()))
                            {
                                foundBool = true; //make true
                                break;
                            }
                        }
                        if(foundBool)
                        {
                            if(investmentList.get(index1) instanceof Stock)
                            {
                                outputMessage.append("Symbol already in Stock"); //let user know
                                exc = true;
                            }
                            else
                            {
                                try
                                {
                                    bookVal = (tempPrice * tempQuan) + 45;
                                    investmentList.get(index1).additional(tempQuan, tempPrice, bookVal);
                                }
                                catch(NumberFormatException nfe)
                                {
                                    outputMessage.append("ERROR: invalid price & quantity\n");
                                    exc = true;
                                }
                            }
                        }
                        else
                        {
                            mutualFundList = new MutualFund();
                            try
                            {
                                mutualFundList.setSym(symIn); //set
                            }
                            catch(Exception r)
                            {
                                outputMessage.append(r.getMessage()); //output message
                                exc = true;
                            }
                            try
                            {
                                mutualFundList.setName(nameOfInv); //set
                            }
                            catch(Exception r)
                            {
                                outputMessage.append(r.getMessage()); //output message
                                exc = true;
                            }
                            try
                            {
                                mutualFundList.setQuantity(tempQuan); //set
                            }
                            catch(NumberFormatException r)
                            {
                                outputMessage.append(r.getMessage()); //output message
                                exc = true;
                            }
                            try
                            {
                                mutualFundList.setPrice(tempPrice); //set
                            }
                            catch(NumberFormatException r){
                                outputMessage.append(r.getMessage()); //output message
                                exc = true;
                            }
                            try
                            {
                                mutualFundList.setBookVal(tempPrice, tempQuan); //set
                            }
                            catch(NumberFormatException r){
                                outputMessage.append("Error creating bookvalue\n");
                            }
                            if(!exc)
                            {
                                investmentList.add(mutualFundList); //move into list
                            }
                        }
                    }
                }
                if(!exc) //if there is an exc
                {
                    hash.clear();
                    sizeInv = investmentList.size();
                    for(index1 = 0; index1 < sizeInv; index1++)
                    {
                        split = investmentList.get(index1).getName().toLowerCase().split("[ ]+"); //split the results
                        for(int count = 0; count < split.length; count++)
                        {
                            location = new ArrayList<Integer>(); //get the location of the keyword
                            if(hash.containsKey(split[count])) //if its contained...
                            {
                                hash.get(split[count]).add(index1); //get the hash
                            }
                            else
                            {
                                location.add(index1);
                                hash.put(split[count], location); //put into list
                            }
                        }
                    }
                    outputMessage.append("Added!"); //let the user know that investment was added
                }
                sym.setText(""); //clear
                name.setText(""); //clear
                quantity.setText(""); //clear
                price.setText(""); //clear
            }
            else if(button.equals("Sell"))
            {
                exc = false;
                String sellingSym = "";
                String sellingPrice = "";
                String sellingQuan = "";
                outputMessage.setText("");
                if(sellSym.getText().isEmpty() || sellSym.getText().isBlank()) //if this is true...
                {
                    outputMessage.append("Enter the symbol you wish to sell\n"); //...then let user know
                    exc = true;
                }
                if(sellQuan.getText().isEmpty() || sellQuan.getText().isBlank()) //if this is true...
                {
                    outputMessage.append("Enter how many shares you wish to sell\n"); //...then let user know
                    exc = true;
                }
                if(sellPrice.getText().isEmpty() || sellPrice.getText().isBlank()) //if this is true...
                {
                    outputMessage.append("Enter how much you wish to sell each s1 for\n"); //...then let user know
                    exc = true;
                }
                else
                {
                    //get the text from the GUI
                    sellingSym = sellSym.getText();
                    sellingQuan = sellQuan.getText();
                    sellingPrice = sellPrice.getText();
                    if(sellingSym.contains(" ")) //get rid of spaces
                    {
                        sellingSym = sellingSym.trim(); //trim
                    }
                    if(sellingQuan.contains(" ")) //get rid of spaces
                    {
                        sellingQuan = sellingQuan.trim(); //trim
                    }
                    if(sellingPrice.contains(" ")) //get rid of spaces
                    {
                        sellingPrice = sellingPrice.trim(); //trim
                    }
                    trueBool = false; //set the exists to false
                    sizeInv = investmentList.size();
                    for(index1 = 0; index1 < sizeInv; index1++) //iterate through the list
                    {
                        if(sellingSym.equalsIgnoreCase(investmentList.get(index1).getSym())) //if the object exists
                        {
                            trueBool = true;
                            break;
                        }
                    }
                    if(trueBool) //if it exists then...
                    {
                        if(investmentList.get(index1) instanceof Stock)
                        {
                            try
                            {
                                sellingShares = Integer.parseInt(sellingQuan); //parse the selling quantity
                            }
                            catch(NumberFormatException nfe)
                            {
                                outputMessage.append("ERROR: invalid price\n"); //let the user know invalid
                                exc = true;
                            }
                            if(sellingShares < 0)
                            {
                                outputMessage.append("ERROR: invalid quantity\n"); //let the user know invalid
                                exc = true;
                            }
                            if(investmentList.get(index1).getQuantity() < sellingShares)
                            {
                                outputMessage.append("Cannot sell "+sellingShares+". You currently have "+investmentList.get(index1).getQuantity()); //let the user know
                                exc = true;
                            }
                            else if(investmentList.get(index1).getQuantity() > sellingShares)
                            {
                                if(!exc)
                                {
                                    try
                                    {
                                        sellPrice1 = Double.parseDouble(sellingPrice);
                                    }
                                    catch(NumberFormatException nfe){
                                        outputMessage.append("ERROR: invalid price\n"); //let the user know invalid
                                        exc = true;
                                    }
                                    if(sellPrice1 < 0.0)
                                    {
                                        outputMessage.append("ERROR: invalid quantity\n"); //let the user know invalid
                                        exc = true;
                                    }
                                    currGain = ((Stock)investmentList.get(index1)).sellBit(sellPrice1, sellingShares); //sell a part of the stock
                                    totGain = totGain +currGain;
                                    if(currGain < 0)
                                    {
                                        currGain = currGain * -1;
                                    }
                                    outputMessage.append("You have profitted/lost $"+ String.format("%.2f",currGain)+"\n"); //output for the user to see
                                    outputMessage.append("Total gain/loss: $"+String.format("%.2f", totGain) + "\n"); //output for the user to see
                                }
                            }
                            else if(investmentList.get(index1).getQuantity() == sellingShares) //for full sell
                            {
                                try
                                {
                                    sellPrice1 = Double.parseDouble(sellingPrice); //parse into double
                                }
                                catch(NumberFormatException nfe)
                                {
                                    outputMessage.append("ERROR: invalid price\n"); //let the user know invalid
                                    exc = true;
                                }
                                if(sellPrice1 < 0.0)
                                {
                                    outputMessage.append("ERROR: invalid quantity\n"); //let the user know invalid
                                    exc = true;
                                }
                                if(!exc)
                                {
                                    currGain = ((Stock)investmentList.get(index1)).sellAll(sellPrice1, sellingShares); //for selling all the shares
                                    totGain = totGain + currGain;
                                    if(currGain < 0)
                                    {
                                        currGain =  currGain * -1;
                                    }
                                    outputMessage.append("You have profitted/lost $"+ String.format("%.2f",currGain)+"\n"); //output for the user to see
                                    outputMessage.append("Total gain/loss: $"+String.format("%.2f", totGain) + "\n"); //output for the user to see
                                    investmentList.remove(index1);
                                }
                            }
                        }
                        else if(investmentList.get(index1) instanceof MutualFund)
                        {
                            try
                            {
                                sellingShares = Integer.parseInt(sellingQuan); //parse the selling quantity
                            }
                            catch(NumberFormatException nfe)
                            {
                                outputMessage.append("ERROR: invalid price\n"); //let the user know invalid
                                exc = true;
                            }
                            if(sellingShares < 0)
                            {
                                outputMessage.append("ERROR: invalid quantity\n"); //let the user know invalid
                                exc = true;
                            }
                            if(investmentList.get(index1).getQuantity() < sellingShares)
                            {
                                outputMessage.append("Cannot sell "+sellingShares+". You currently have "+investmentList.get(index1).getQuantity()); //let the user know
                                exc = true;
                            }
                            else if(investmentList.get(index1).getQuantity() > sellingShares)
                            {
                                if(!exc)
                                {
                                    try
                                    {
                                        sellPrice1 = Double.parseDouble(sellingPrice);
                                    }
                                    catch(NumberFormatException nfe){
                                        outputMessage.append("ERROR: invalid price\n"); //let the user know invalid
                                        exc = true;
                                    }
                                    if(sellPrice1 < 0.0)
                                    {
                                        outputMessage.append("ERROR: invalid quantity\n"); //let the user know invalid
                                        exc = true;
                                    }
                                    currGain = ((MutualFund)investmentList.get(index1)).sellBit(sellPrice1, sellingShares); //sell a part of the mutual fund
                                    totGain = totGain + currGain;
                                    if(currGain < 0)
                                    {
                                        currGain = currGain * -1;
                                    }
                                    outputMessage.append("You have profitted/lost $"+ String.format("%.2f",currGain)+"\n"); //output for the user to see
                                    outputMessage.append("Total gain/loss: $"+String.format("%.2f", totGain) + "\n"); //output for the user to see
                                }
                            }
                            else if(investmentList.get(index1).getQuantity() == sellingShares) //for full sell
                            {
                                try
                                {
                                    sellPrice1 = Double.parseDouble(sellingPrice); //parse into double
                                }
                                catch(NumberFormatException nfe)
                                {
                                    outputMessage.append("ERROR: invalid price\n"); //let the user know invalid
                                    exc = true;
                                }
                                if(sellPrice1 < 0.0)
                                {
                                    outputMessage.append("ERROR: invalid quantity\n"); //let the user know invalid
                                    exc = true;
                                }
                                if(!exc)
                                {
                                    currGain = ((MutualFund)investmentList.get(index1)).sellAll(sellPrice1, sellingShares); //for selling all the shares
                                    totGain = totGain + currGain;
                                    if(currGain < 0)
                                    {
                                        currGain = currGain * -1;
                                    }
                                    outputMessage.append("You have profitted/lost $"+ String.format("%.2f",currGain)+"\n"); //output for the user to see
                                    outputMessage.append("Total gain/loss: $"+String.format("%.2f", totGain) + "\n"); //output for the user to see
                                    investmentList.remove(index1);
                                }
                            }
                        }
                    }
                    else
                    {
                        outputMessage.append("No such investment in your investmentList\n"); //let the user know that no investment exists
                        exc = true;
                    }
                    hash.clear(); //clear the hash
                    sizeInv = investmentList.size();
                    for(index1 = 0; index1 < sizeInv; index1++)
                    {
                        split = investmentList.get(index1).getName().toLowerCase().split("[ ]+"); //split the results
                        for(int count = 0; count < split.length; count++)
                        {
                            location = new ArrayList<Integer>(); //get the location of the keyword
                            if(hash.containsKey(split[count])) //if its contained...
                            {
                                hash.get(split[count]).add(index1); //get the hash
                            }
                            else
                            {
                                location.add(index1);
                                hash.put(split[count], location); //put into list
                            }
                        }
                    }
                    if(!exc)
                    {
                        outputMessage.append("Sold!\n"); //output the message to the user
                    }
                }
                sellSym.setText(""); //clear
                sellQuan.setText(""); //clear
                sellPrice.setText(""); //clear
            }
            else if(button.equals("Previous"))
            {
                nextButton.setEnabled(true); //enable the button
                if(index2 == 0)
                {
                    prevButton.setEnabled(false); //disable the button
                }
                else
                {
                    index2 = index2 - 1;
                }
                symNew.setText(investmentList.get(index2).getSym()); //get sym
                nameNew.setText(investmentList.get(index2).getName()); //get name
                priceNew.setText(""); //make empty
            }
            else if(button.equals("Next"))
            { 
                prevButton.setEnabled(true); //enable the button
                if(index2 == investmentList.size() - 1)
                {
                    nextButton.setEnabled(false);
                }
                else
                {
                    index2 = index2 + 1;
                }
                symNew.setText(investmentList.get(index2).getSym()); //get sym
                nameNew.setText(investmentList.get(index2).getName()); //get name
                priceNew.setText(""); //make empty
            }
            else if(button.equals("Save"))
            {
                if(priceNew.getText().isEmpty() || priceNew.getText().isBlank()) //if the user leaves it blank
                {
                    outputMessage.append("ERROR: invalid price\n"); //let the user know
                }
                else
                {
                    if(priceNew.getText().contains(" ")) //if the text has space
                    {
                        priceNew.getText().trim(); //trim
                    }
                    try
                    {
                        if(investmentList.get(index2) instanceof Stock)
                        {
                            ((Stock)investmentList.get(index2)).update(Double.parseDouble((priceNew.getText())));
                        }
                        else if(investmentList.get(index2) instanceof MutualFund)
                        {
                            ((MutualFund)investmentList.get(index2)).update(Double.parseDouble((priceNew.getText())));
                        }
                        moveThrough = 1;
                    }
                    catch(NumberFormatException nfe)
                    {
                        outputMessage.append("ERROR: invalid price\n");
                        moveThrough = 0;
                    }
                    if(moveThrough == 1)
                    {
                        outputMessage.append("\nUpdate:\n");
                        outputMessage.append(investmentList.get(index2).toString());
                    }
                }
            }
            else if(button.equals("Search"))
            {
                //define array lists
                ArrayList<Investment> tempArrayList = new ArrayList<Investment>();
                ArrayList<Integer> index = new ArrayList<Integer>();
                ArrayList<ArrayList<Integer>> holder = new ArrayList<ArrayList<Integer>>();
                outputMessage.setText("");
                //define all other variables
                String keyW[] = new String[10];
                String tempKey = "";
                String symChosen = "";
                double lowerNum = 0;
                double higherNum = 0;
                //set all the booleans to false
                boolean emptySym = false;
                boolean emptyKeyW = false;
                boolean lower = false;
                boolean upper = false;
                boolean find = false;

                //if empty...
                if(sym.getText().isBlank() || sym.getText().isEmpty())
                {
                    emptySym = true;
                }
                else
                {
                    symChosen = sym.getText();
                }
                //if empty...
                if(match.getText().isBlank() || match.getText().isEmpty())
                {
                    emptyKeyW = true;
                }
                else
                {
                    tempKey = match.getText(); //let the user enter the keywords 
                }
                keyW = tempKey.split("[ ]+");
                if(low.getText().isBlank() || low.getText().isEmpty())
                {
                    lower = true;
                }
                else
                {
                    try
                    {
                        lowerNum = Integer.parseInt(low.getText());
                    }
                    catch(NumberFormatException nfe)
                    {
                        outputMessage.append("ERROR: invalid lower\n");
                        exc = true;
                    }
                    if(lowerNum < 0)
                    {
                        outputMessage.append("ERROR: invalid lower\n");
                        exc = true;
                    }
                }
                if(high.getText().isBlank() || high.getText().isEmpty())
                {
                    upper = true;
                }
                else
                {
                    try
                    {
                        higherNum = Integer.parseInt(high.getText());
                    }
                    catch(NumberFormatException nfe)
                    {
                        outputMessage.append("ERROR: invalid upper\n");
                        exc = true;
                    }
                    if(higherNum < 0)
                    {
                        outputMessage.append("ERROR: invalid upper\n");
                        exc = true;
                    }
                }
                //make a list for investments with the symbols inputted with no keyword
                if(emptyKeyW)
                {
                    int iterate = 0;
                    while(iterate < investmentList.size())
                    {
                        if(!emptySym) //if symbol is valid
                        {
                            if(investmentList.get(iterate).getSym().compareToIgnoreCase(symChosen) == 0)
                            {
                                //add to list
                                tempArrayList.add(investmentList.get(iterate));
                            }
                        }
                        else //if symbol is not valid
                        {
                            tempArrayList.add(investmentList.get(iterate));
                        }
                        iterate++;
                    }
                }
                else ////make a list for investments with the symbols inputted with keyword
                {
                    int iterate = 0;
                    while(iterate < keyW.length)
                    {
                        //search the arrayList hashMap
                        for(Map.Entry<String, ArrayList<Integer>> set : hash.entrySet())
                        {
                            if(set.getKey().equalsIgnoreCase(keyW[iterate]))
                            {
                                index.addAll(set.getValue());
                                holder.add(set.getValue());
                            }
                        }
                        iterate++;
                    }
                    if(keyW.length > 1)
                    {
                        iterate = 0;
                        while(iterate < holder.size()) //recieves the intersection of the index
                        {
                            holder.get(0).retainAll(holder.get(iterate));
                            iterate++;
                        }
                        iterate = 0;
                        while(iterate < holder.get(0).size()) //assigns the indexes to the list
                        {
                            tempArrayList.add(investmentList.get(holder.get(0).get(iterate)));
                            iterate++;
                        }
                    }
                    else
                    {
                        iterate = 0;
                        while(iterate < index.size())
                        {
                            tempArrayList.add(investmentList.get(index.get(iterate)));
                            iterate++;
                        }
                    }
                }

                if(!lower && !upper) //make a list for investments with the symbols inputted with no empty range
                {
                    if(lower) //if only upper end
                    {
                        int iterate = 0;
                        while(iterate < tempArrayList.size())
                        {
                            find = false;
                            if(tempArrayList.get(iterate).getPrice() >= lowerNum)
                            {
                                find = true;
                            }
                            if(!find)
                            {
                                tempArrayList.remove(iterate);
                                iterate = 0;
                            }
                            iterate++;
                        }
                    }
                    else if(upper) //if only lower end
                    {
                        int iterate = 0;
                        while(iterate < tempArrayList.size())
                        {
                            find = false;
                            if(tempArrayList.get(iterate).getPrice() <= higherNum)
                            {
                                find = true;
                            }
                            if(!find)
                            {
                                tempArrayList.remove(iterate);
                                iterate = 0;
                            }
                            iterate++;
                        }
                    }
                    else
                    {
                        int iterate = 0;
                        for(iterate = 0; iterate < tempArrayList.size(); iterate++)
                        {
                            find = false;
                            if(tempArrayList.get(iterate).getPrice() >= lowerNum && tempArrayList.get(iterate).getPrice() <= higherNum)
                            {
                                find = true;
                            }
                            if(!find)
                            {
                                tempArrayList.remove(iterate);
                                iterate = 0;
                            }
                        }
                    }
                }
                //print the found searches
                outputMessage.append("Matched Search:\n");
                int iterate = 0;
                while(iterate < tempArrayList.size())
                {
                    outputMessage.append((tempArrayList.get(iterate)).toString());
                    iterate++;
                }
                sym.setText(""); //clear
                name.setText(""); //clear
                match.setText(""); //clear
                low.setText(""); //clear
                high.setText(""); //clear
            }  
        }
    }
    /**
     * prepares the GUI
     */
    public Portfolio(){
        super();
        prepareGUI();
    }
    /**
     * output the GUI
     */
    public void prepareGUI()
    {
        //initialize everything
        setTitle("Shaan's Stonks");
        setSize(800, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        controlPanel = new JPanel();
        controlPanel.setLayout(new GridLayout());
         
        //fix text later
        Font titleFont = new Font(Font.SERIF, Font.BOLD, 25);
        header = new JLabel("<html>Welcome to ePortfolio.<br><br>Choose a command from the Commands menu to buy or sell an investment, update prices for all investmentList, get gain for the portfolio, search for relevant investmentList, or quit the program.<html>", JLabel.LEFT);
        header.setFont(titleFont);
        //list of the options for the user
        JMenu commands = new JMenu("Commands");
        JMenuItem buy = new JMenuItem("Buy New investmentList");
        JMenuItem sell = new JMenuItem("Sell Existing investmentList");
        JMenuItem updateMenu = new JMenuItem("Update Prices of Existing investmentList");
        JMenuItem getGain = new JMenuItem("Get The Gain of Your Portfolio");
        JMenuItem search = new JMenuItem("Search For An Investment");
        JMenuItem exit = new JMenuItem("Quit");
        JMenuBar menuBar = new JMenuBar();

        //let the user choose the command
        buy.addActionListener(select);
        commands.add(buy);
        sell.addActionListener(select);
        commands.add(sell);
        updateMenu.addActionListener(select);
        commands.add(updateMenu);
        getGain.addActionListener(select);
        commands.add(getGain);
        search.addActionListener(select);
        commands.add(search);
        exit.addActionListener(select);
        commands.add(exit);
        menuBar.add(commands);
        controlPanel.add(menuBar);
        setJMenuBar(menuBar);
        add(header);
    }
}
